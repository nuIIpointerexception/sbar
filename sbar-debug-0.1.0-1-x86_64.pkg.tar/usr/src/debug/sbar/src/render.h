#ifndef RENDER_H
#define RENDER_H

#include "state.h"

void render(void *data, struct state *state);

#endif
