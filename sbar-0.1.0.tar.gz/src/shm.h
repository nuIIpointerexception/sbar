#ifndef SHM_H
#define SHM_H

#include <sys/types.h>

int allocate_shm_file(size_t size);

#endif
